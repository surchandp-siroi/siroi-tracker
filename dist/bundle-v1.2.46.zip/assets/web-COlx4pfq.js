import{W as n}from"./main-Lnfj9KYs.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
