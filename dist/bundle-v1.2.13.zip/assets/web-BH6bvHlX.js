import{W as n}from"./main-C7QncHUQ.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
